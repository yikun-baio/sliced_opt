# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 11:58:08 2022

@author: laoba
"""

import numpy as np
import math
from library import *
from opt import *
import torch
import ot
from ot.sliced import get_random_projections

def random_projections(d,n_projections):
    Gaussian_vector=torch.normal(0,1,size=[d,n_projections])
    theta_list=Gaussian_vector/np.sqrt(sum(Gaussian_vector**2))    
    return theta_list 

    


def sliced_opt(X,Y,Lambda=40,n_projections=1000):
    '''
    X: X is n*d dimension array
    Y: Y is m*d dimension array
    '''
    d=X.shape[1]
    projections=random_projections(d,n_projections)
#    X=list_to_array(X)
#    Y=list_to_array(Y)

    
    X_sliced=torch.matmul(projections.T,X.T)
    Y_sliced=torch.matmul(projections.T,Y.T)
    cost_sum=0
    for i in range(0,n_projections):
        X_theta=X_sliced[i,:]
        Y_theta=Y_sliced[i,:]
        X_theta=X_theta.sort().values
        Y_theta=Y_theta.sort().values
     #   print(X_theta)
     #   print(Y_theta)
        cost,L=opt_1d_v3(X_theta, Y_theta, Lambda)
        cost_sum+=cost
    cost_sum=cost_sum/n_projections
    return cost_sum




